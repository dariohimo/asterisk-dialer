export PATH=$PATH:/usr/java/j2sdk1.4.2_08/bin
export CLASSPATH=$CLASSPATH:.
